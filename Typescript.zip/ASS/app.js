const axios = require('axios')

axios.get('https://fakestoreapi.com/products').then(res=>{
    res.forEach(element => {
       console.log(element) 
    });
})