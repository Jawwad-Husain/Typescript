"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var axios_1 = require("axios");
axios_1.default.get('https://fakestoreapi.com/products').then(function (res) {
    res.data.forEach(function (element) {
        console.log(element);
    });
});
fetch("https://fakestoreapi.com/products").then((data)=>{
    // console.log(data);
    return data.json();
}).then((objectData)=>{
    console.log(objectData[0].title);
    let Data="";
    objectData.map((values)=>{
        Data+=`<h1>${values.title}</h1>`;
    });
    document.getElementById("table_body").innerHTML=Data;
})