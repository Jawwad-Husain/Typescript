import axios from "axios";

axios.get('https://fakestoreapi.com/products').then((res)=>{
    res.data.forEach((element:any) => {
        console.log(element)
    });
})

//https://random-data-api.com/api/stripe/random_stripe?size=5